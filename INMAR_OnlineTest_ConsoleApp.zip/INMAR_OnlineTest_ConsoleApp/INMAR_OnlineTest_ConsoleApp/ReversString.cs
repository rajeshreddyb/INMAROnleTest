﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INMAR_OnlineTest_ConsoleApp
{
   static class ReversString
    {
        //Write a program to reverse a string “abcdef” --> “fedcba” without using the .NET reverse() function
        public static void ReverseString()
        {
            string revString = string.Empty; // String type is immutable(con't change) every time new value store in stach ;
            string inputString = "abcdef";

            for(int i = 0; i < inputString.Length; i++)
            {

                revString = inputString[i] + revString;
            }

            Console.WriteLine(revString);
            Console.ReadLine();

        }
    }
}
